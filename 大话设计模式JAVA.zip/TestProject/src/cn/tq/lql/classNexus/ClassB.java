package cn.tq.lql.classNexus;

public class ClassB {
	public void showMessage(){
		System.out.println("this message from ClassB");
	}
	public static void staticShowMessage(){
		System.out.println("this message from ClassB");
	}
}

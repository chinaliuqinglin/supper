package cn.tq.lql.observerPattern;

public class ConcreateSubject extends Subject {
	private String state;

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	
	
}

package cn.tq.lql.observerPattern;   
  
import java.lang.reflect.Method;   
@SuppressWarnings("rawtypes")
public class Event {   
    //Ҫִ�з����Ķ���   
    private Object object;   
    //Ҫִ�еķ�������   
    private String methodName;   
    //Ҫִ�з����Ĳ���   
    private Object[] params;   
    //Ҫִ�з����Ĳ�������   
	private Class[] paramTypes;   
       
    public Event(Object object,String methodName,Object...args){   
        this.object=object;   
        this.methodName=methodName;   
        this.params=args;   
        contractParamTypes(this.params);   
    }   
    //���ݲ����������ɲ�����������   
    private void contractParamTypes(Object[] params){ 
    	if(null==params || params.length==0)
    		return;
        this.paramTypes=new Class[params.length];   
        for(int i=0;i<params.length;i++){   
            this.paramTypes[i]=params[i].getClass();   
        }   
    }   
       
    public void invoke() throws Exception{   
        Method method=object.getClass().getMethod(this.getMethodName(), this.getParamTypes());   
        if(null==method){   
            return;   
        }   
        method.invoke(this.getObject(), this.getParams());   
    }
    
	public Object getObject() {
		return object;
	}
	public void setObject(Object object) {
		this.object = object;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	public Object[] getParams() {
		return params;
	}
	public void setParams(Object[] params) {
		this.params = params;
	}
	public Class[] getParamTypes() {
		return paramTypes;
	}
	public void setParamTypes(Class[] paramTypes) {
		this.paramTypes = paramTypes;
	}   
}  
package cn.tq.lql.observerPattern;

public class ConcreateObserver extends Observer {
	private String name;
	private String state;
	private ConcreateSubject concreateSubject;

	public ConcreateObserver(String name,ConcreateSubject concreateSubject){
		this.name=name;
		this.concreateSubject=concreateSubject;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public ConcreateSubject getConcreateSubject() {
		return concreateSubject;
	}

	public void setConcreateSubject(ConcreateSubject concreateSubject) {
		this.concreateSubject = concreateSubject;
	}

	@Override
	public void update() {
		state=concreateSubject.getState();
		System.out.println("�۲��ߣ�"+name);
		System.out.println("��״̬��"+state);
	}

}

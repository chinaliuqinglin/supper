package cn.tq.lql.observerPattern;

public abstract class Observer {
	public abstract void update();
}

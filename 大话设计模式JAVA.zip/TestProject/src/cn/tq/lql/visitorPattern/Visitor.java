package cn.tq.lql.visitorPattern;

public abstract class Visitor {
	public abstract void visitConcreateElementA(ConcreateElementA elementA);
	public abstract void visitConcreateElementB(ConcreateElementB elementB);
}

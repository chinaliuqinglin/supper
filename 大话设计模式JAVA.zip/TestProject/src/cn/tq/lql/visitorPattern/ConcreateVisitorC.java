package cn.tq.lql.visitorPattern;

public class ConcreateVisitorC extends Visitor{

	@Override
	public void visitConcreateElementA(ConcreateElementA elementA) {
		System.out.println(elementA.getClass().getSimpleName()+"��"+this.getClass().getSimpleName()+"����");
	}

	@Override
	public void visitConcreateElementB(ConcreateElementB elementB) {
		System.out.println(elementB.getClass().getSimpleName()+"��"+this.getClass().getSimpleName()+"����");
	}

}

package cn.tq.lql.visitorPattern;

public abstract class Element {
	public abstract void accept(Visitor visitor);
}

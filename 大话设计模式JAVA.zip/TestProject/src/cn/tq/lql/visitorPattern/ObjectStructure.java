package cn.tq.lql.visitorPattern;

import java.util.ArrayList;
import java.util.List;

public class ObjectStructure {
	private List<Element> elemnets=new ArrayList<Element>();
	
	public void attach(Element element){
		elemnets.add(element);
	}
	
	public void detach(Element element){
		elemnets.remove(element);
	}
	
	public void accept(Visitor visitor){
		if(null!=elemnets && elemnets.size()>0){
			for(Element element:elemnets){
				element.accept(visitor);
			}
		}
	}
}

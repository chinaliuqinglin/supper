package cn.tq.lql.visitorPattern;

public class ConcreateElementA extends Element {

	@Override
	public void accept(Visitor visitor) {
		visitor.visitConcreateElementA(this);
	}
}

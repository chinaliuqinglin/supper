package cn.tq.lql.visitorPattern;

public class ConcreateElementB extends Element {
	@Override
	public void accept(Visitor visitor) {
		visitor.visitConcreateElementB(this);
	}
}

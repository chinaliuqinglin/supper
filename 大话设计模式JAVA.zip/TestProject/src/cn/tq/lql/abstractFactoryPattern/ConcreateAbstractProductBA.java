package cn.tq.lql.abstractFactoryPattern;

public class ConcreateAbstractProductBA implements AbstractProductB{
	private String name;
	private String age;
	
	public ConcreateAbstractProductBA(String name,String age){
		this.name=name;
		this.age=age;
	}

	@Override
	public void printSelfProperty() {
		System.out.println("name="+name);
		System.out.println("age="+age);
		System.out.println("---------------------");
	}

}

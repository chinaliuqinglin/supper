package cn.tq.lql.abstractFactoryPattern;

public interface AbstractFactory {
	public AbstractProductA factoryProductA();
	public AbstractProductB factoryProductB();
}

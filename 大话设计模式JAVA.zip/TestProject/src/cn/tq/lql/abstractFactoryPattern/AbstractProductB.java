package cn.tq.lql.abstractFactoryPattern;

public interface AbstractProductB {
	public void printSelfProperty();
}

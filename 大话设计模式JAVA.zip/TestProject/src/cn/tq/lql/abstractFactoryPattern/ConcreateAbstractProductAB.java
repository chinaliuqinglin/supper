package cn.tq.lql.abstractFactoryPattern;

public class ConcreateAbstractProductAB implements AbstractProductA{
	private String name;
	
	
	public ConcreateAbstractProductAB(String name){
		this.name=name;
	}


	@Override
	public void showMessage(String msg) {
		System.out.println(name +" receive msg:"+msg);
		System.out.println("---------------------");

	}

}

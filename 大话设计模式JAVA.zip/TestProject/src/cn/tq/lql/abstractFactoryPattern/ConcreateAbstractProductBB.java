package cn.tq.lql.abstractFactoryPattern;

public class ConcreateAbstractProductBB implements AbstractProductB {
	private String name;
	private String gender;

	public ConcreateAbstractProductBB(String name,String gender){
		this.name=name;
		this.gender=gender;
	}

	@Override
	public void printSelfProperty() {
		System.out.println("name=" + name);
		System.out.println("gender=" + gender);
		System.out.println("---------------------");
	}

}

package cn.tq.lql.abstractFactoryPattern;

public class ConcreateFactoryB implements AbstractFactory{

	@Override
	public AbstractProductA factoryProductA() {
		return new ConcreateAbstractProductAB("����");
	}

	@Override
	public AbstractProductB factoryProductB() {
		return new ConcreateAbstractProductBB("����","��");

	}

}

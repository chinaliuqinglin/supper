package cn.tq.lql.abstractFactoryPattern;

public class ConcreateFactoryA implements AbstractFactory{

	@Override
	public AbstractProductA factoryProductA() {
		return new ConcreateAbstractProductAA();
	}

	@Override
	public AbstractProductB factoryProductB() {
		return new ConcreateAbstractProductBA("����","18");
	}

}

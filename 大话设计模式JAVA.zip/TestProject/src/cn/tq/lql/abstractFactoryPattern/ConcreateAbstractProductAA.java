package cn.tq.lql.abstractFactoryPattern;

public class ConcreateAbstractProductAA implements AbstractProductA{

	@Override
	public void showMessage(String msg) {
		System.out.println("new msg:"+msg);
		System.out.println("---------------------");

	}

}

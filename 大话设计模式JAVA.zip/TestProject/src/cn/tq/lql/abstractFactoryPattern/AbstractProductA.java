package cn.tq.lql.abstractFactoryPattern;

public interface AbstractProductA {
	public void showMessage(String msg);
}

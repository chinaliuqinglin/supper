package cn.tq.lql.flyweightPattern;

public abstract class Flyweight {

	public abstract void operation(int extrinsicstate);

}

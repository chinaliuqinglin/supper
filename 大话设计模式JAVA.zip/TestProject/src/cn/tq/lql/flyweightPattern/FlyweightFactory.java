package cn.tq.lql.flyweightPattern;

import java.util.HashMap;
import java.util.Map;

public class FlyweightFactory {
	private Map<Integer,Flyweight> flyweights=new HashMap<Integer,Flyweight>();
	
	public FlyweightFactory(){
		flyweights.put(1, new ConcreateFlyweight());
		flyweights.put(2, new ConcreateFlyweight());
		flyweights.put(3, new ConcreateFlyweight());
	}
	
	public Flyweight getFlyweight(int key){
		return flyweights.get(key);
	}
}

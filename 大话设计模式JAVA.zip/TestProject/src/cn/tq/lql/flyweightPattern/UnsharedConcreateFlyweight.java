package cn.tq.lql.flyweightPattern;

public class UnsharedConcreateFlyweight extends Flyweight{

	@Override
	public void operation(int extrinsicstate) {
		System.out.println("����������flyweight "+extrinsicstate);
	}

}

package cn.tq.lql.flyweightPattern;

public class ConcreateFlyweight extends Flyweight {

	@Override
	public void operation(int extrinsicstate) {
		System.out.println("����flyweight "+extrinsicstate);
	}

}

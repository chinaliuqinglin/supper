package cn.tq.lql.templatePattern;

public class ConcreateClassA extends AbstractClass {

	@Override
	public void primitiveOperationA() {
		System.out.println("classsA operation A");

	}

	@Override
	public void primitiveOperationB() {
		System.out.println("classsA operation B");
	}

}

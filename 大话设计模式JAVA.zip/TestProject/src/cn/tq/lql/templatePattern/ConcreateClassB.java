package cn.tq.lql.templatePattern;

public class ConcreateClassB extends AbstractClass {

	@Override
	public void primitiveOperationA() {
		System.out.println("classsB operation A");

	}

	@Override
	public void primitiveOperationB() {
		System.out.println("classsB operation B");
	}

}

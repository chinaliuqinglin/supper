package cn.tq.lql.commandPattern;

public class ConcreateCommand extends Command {
	protected Receiver receiver;

	public ConcreateCommand(Receiver receiver) {
		this.receiver = receiver;
	}

	@Override
	public void execute() {
		
		
		receiver.action();
	}

	@Override
	public void undo() {
		receiver.unAction();
		
	}

}

package cn.tq.lql.bridgePattern;

public abstract class Implementor {
	public abstract void operation();
}

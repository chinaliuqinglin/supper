package cn.tq.lql.bridgePattern;

public class RefinedAbstraction extends Abstraction {

	@Override
	public void operation() {
		implementor.operation();
	}

}

package cn.tq.lql.bridgePattern;

public class ConcreateImplementorA extends Implementor{

	@Override
	public void operation() {
		System.out.println("A��ʵ��");
	}

}

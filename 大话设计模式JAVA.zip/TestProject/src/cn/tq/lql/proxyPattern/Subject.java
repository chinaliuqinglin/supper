package cn.tq.lql.proxyPattern;

public interface Subject {
	public void request();
	
	public void request2();
}

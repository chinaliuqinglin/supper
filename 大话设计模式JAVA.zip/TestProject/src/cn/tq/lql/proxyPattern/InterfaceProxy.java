package cn.tq.lql.proxyPattern;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
public class InterfaceProxy {
	public Object target;
	
	public InterfaceProxy(Object target){
		this.target=target;
	}
	
	 public Object getProxyInstance(){
		 return Proxy.newProxyInstance(
	                target.getClass().getClassLoader(),
	                target.getClass().getInterfaces(),
	                new InvocationHandler() {
	                    @Override
	                    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
	                        System.out.println("interface proxy");
	                        //ִ��Ŀ����󷽷�
	                        Object returnValue = method.invoke(target, args);
	                        return returnValue;
	                    }
	                }
	        );
	    }
}

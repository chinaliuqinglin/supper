package cn.tq.lql.proxyPattern;

public class RequestTarget {
	public String name;
	
	public RequestTarget(String name){
		this.name=name;
	}
}

package cn.tq.lql.proxyPattern;

public class RealSubject implements Subject {

	@Override
	public void request() {
		System.out.println("��ʵ����");
	}

	@Override
	public void request2() {
		System.out.println("��ʵ����2");
		
	}

}

package cn.tq.lql.proxyPattern;

public class Proxy implements Subject {
	RealSubject realSubject;
	
	public Proxy(RealSubject realSubject){
		this.realSubject=realSubject;
	}
	
	@Override
	public void request() {
		System.out.println("static proxy");
		realSubject.request();
	}

	@Override
	public void request2() {
		System.out.println("static proxy 2");
		realSubject.request2();
		
	}

}

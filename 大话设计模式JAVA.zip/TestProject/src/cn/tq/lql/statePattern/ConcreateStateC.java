package cn.tq.lql.statePattern;

public class ConcreateStateC implements State{

	@Override
	public void handle(Context context) {
		context.setState(new ConcreateStateA());
	}

}

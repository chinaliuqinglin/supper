package cn.tq.lql.statePattern;

public interface State {
	public void handle(Context context);
}

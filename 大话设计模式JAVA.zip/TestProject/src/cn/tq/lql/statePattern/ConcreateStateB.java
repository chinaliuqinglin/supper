package cn.tq.lql.statePattern;

public class ConcreateStateB implements State{

	@Override
	public void handle(Context context) {
		context.setState(new ConcreateStateC());
	}

}

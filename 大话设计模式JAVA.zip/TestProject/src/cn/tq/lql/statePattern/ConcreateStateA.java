package cn.tq.lql.statePattern;

public class ConcreateStateA implements State{

	@Override
	public void handle(Context context) {
		context.setState(new ConcreateStateB());
	}

}

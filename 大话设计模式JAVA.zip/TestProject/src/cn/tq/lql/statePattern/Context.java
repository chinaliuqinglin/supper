package cn.tq.lql.statePattern;

public class Context {
	private State state;
	
	public Context(State state){
		this.state=state;
		System.out.println("��ǰ״̬Ϊ��"+state.getClass().getSimpleName());
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
		System.out.println("��ǰ״̬Ϊ��"+state.getClass().getSimpleName());
	}
	
	public void request(){
		state.handle(this);
	}
}

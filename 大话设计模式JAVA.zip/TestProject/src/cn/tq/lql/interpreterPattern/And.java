package cn.tq.lql.interpreterPattern;

public class And extends AbstractExpression {

    private AbstractExpression left,right;
    
    public And(AbstractExpression left , AbstractExpression right){
        this.left = left;
        this.right = right;
    }
    
    @Override
    public boolean equals(Object obj) {
        if(obj != null && obj instanceof And)
        {
            return left.equals(((And)obj).left) &&
                right.equals(((And)obj).right);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return this.toString().hashCode();
    }

    @Override
    public boolean interpret(Context ctx) {
        
        return left.interpret(ctx) && right.interpret(ctx);
    }

    @Override
    public String toString() {
        return "(" + left.toString() + " AND " + right.toString() + ")";
    }

}

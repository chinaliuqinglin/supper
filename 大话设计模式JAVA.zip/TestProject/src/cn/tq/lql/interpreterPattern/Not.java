package cn.tq.lql.interpreterPattern;

public class Not extends AbstractExpression {

	private AbstractExpression expression;

	public Not(AbstractExpression expression) {
		this.expression = expression;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj != null && obj instanceof Not) {
			return expression.equals(((Not) obj).expression);
		}
		return false;
	}

	@Override
	public int hashCode() {
		return this.toString().hashCode();
	}

	@Override
	public boolean interpret(Context ctx) {
		return !expression.interpret(ctx);
	}

	@Override
	public String toString() {
		return "(Not " + expression.toString() + ")";
	}

}
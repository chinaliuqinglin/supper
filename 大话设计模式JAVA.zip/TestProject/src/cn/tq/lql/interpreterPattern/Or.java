package cn.tq.lql.interpreterPattern;

public class Or extends AbstractExpression {
    private AbstractExpression left,right;

    public Or(AbstractExpression left , AbstractExpression right){
        this.left = left;
        this.right = right;
    }
    @Override
    public boolean equals(Object obj) {
        if(obj != null && obj instanceof Or)
        {
            return this.left.equals(((Or)obj).left) && this.right.equals(((Or)obj).right);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return this.toString().hashCode();
    }

    @Override
    public boolean interpret(Context ctx) {
        return left.interpret(ctx) || right.interpret(ctx);
    }

    @Override
    public String toString() {
		return "(" + left.toString() + " OR " + right.toString() + ")";
    }

}

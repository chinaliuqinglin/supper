package cn.tq.lql.interpreterPattern;

public abstract class AbstractExpression {
	public abstract boolean interpret(Context context);
	
	public abstract boolean equals(Object object);
	
	public abstract int hashCode();
	
	public abstract String toString();
}

package cn.tq.lql.strategyPattern;

public class Context {
	Strategy strategy;
	public Context(Strategy strategy){
		this.strategy=strategy;
	}
	
	//ʹ�ü򵥹���ģʽ��������
	public Context(String strategy) throws Exception{
		if(strategy.equals("A")){
			this.strategy=new ConcreateStrategyA();
		}else if(strategy.equals("B")){
			this.strategy=new ConcreateStrategyB();
		}else if(strategy.equals("C")){
			this.strategy=new ConcreateStrategyC();
		}else{
			throw new Exception("��֧�ָ��㷨");
		}
	}
	
	public void ContextInterface(){
		strategy.algorithmInterface();
	}
}

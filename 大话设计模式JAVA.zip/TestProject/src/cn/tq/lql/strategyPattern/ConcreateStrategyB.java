package cn.tq.lql.strategyPattern;

public class ConcreateStrategyB extends Strategy {

	@Override
	public void algorithmInterface() {
		System.out.println("�㷨Bʵ��");
	}

}

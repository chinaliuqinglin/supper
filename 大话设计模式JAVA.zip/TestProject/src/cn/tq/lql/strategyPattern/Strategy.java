package cn.tq.lql.strategyPattern;

public abstract class Strategy {
	public abstract void algorithmInterface();
}

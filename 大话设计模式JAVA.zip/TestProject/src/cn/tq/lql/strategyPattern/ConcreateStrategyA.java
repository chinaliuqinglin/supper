package cn.tq.lql.strategyPattern;

public class ConcreateStrategyA extends Strategy {

	@Override
	public void algorithmInterface() {
		System.out.println("�㷨Aʵ��");
	}

}

package cn.tq.lql.strategyPattern;

public class ConcreateStrategyC extends Strategy {

	@Override
	public void algorithmInterface() {
		System.out.println("�㷨Cʵ��");
	}

}

package cn.tq.lql.prototypePattern;

public class ConcreatePrototypeA extends Prototype{
	
	public ConcreatePrototypeA(String name, String age) {
		super(name, age);
	}
	

	@Override
	public Prototype clone() {
		return new ConcreatePrototypeA(this.name,this.age);
	}


	@Override
	public Prototype deepClone() {
		return new ConcreatePrototypeA(this.name,this.age);
	}

}

package cn.tq.lql.prototypePattern;

public abstract class Prototype{
	protected String name;
	protected String age;

	public Prototype(String name,String age){
		this.name=name;
		this.age=age;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}
	
	public abstract Prototype clone(); 
	
	public abstract Prototype deepClone(); 
	
	protected void show(){
		System.out.println("name="+name+" and age="+age);
	}

}

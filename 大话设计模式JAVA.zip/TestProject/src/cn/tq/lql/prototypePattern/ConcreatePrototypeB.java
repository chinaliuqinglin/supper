package cn.tq.lql.prototypePattern;

public class ConcreatePrototypeB extends Prototype{
	private Prototype prototype;
	
	public ConcreatePrototypeB(String name, String age,Prototype prototype) {
		super(name, age);
		this.prototype=prototype;
	}
	

	public Prototype getPrototype() {
		return prototype;
	}
	
	@Override
	public void show() {
		super.show();
		System.out.println("my prototype property name="+prototype.getName()+" and age="+prototype.getAge());
	}


	@Override
	public Prototype clone() {
		return new ConcreatePrototypeB(this.name,this.age,this.prototype);
	}


	@Override
	public Prototype deepClone() {
		return new ConcreatePrototypeB(this.name,this.age,prototype.deepClone());
	}
	

}

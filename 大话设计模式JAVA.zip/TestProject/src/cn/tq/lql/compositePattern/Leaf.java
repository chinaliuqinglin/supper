package cn.tq.lql.compositePattern;

public class Leaf extends Componet {

	public Leaf(String name) {
		super(name);
	}

	@Override
	public void add(Componet componet) {
		System.out.println("can't add to a leaf");
	}

	@Override
	public void remove(Componet componet) {
		System.out.println("can't remove from a leaf");
	}

	@Override
	public void display(int depth) {
		System.out.println(getFormaterByDepth(depth) + name);
	}

}

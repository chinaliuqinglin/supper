package cn.tq.lql.compositePattern;

public abstract class Componet {
	protected String name;
	
	public Componet(String name){
		this.name=name;
	}
	
	public abstract void add(Componet componet);
	public abstract void remove(Componet componet);
	public abstract void display(int depth);
	
	protected String getFormaterByDepth(int depth){
		StringBuffer result=new StringBuffer();
		for(int i=0;i<depth;i++){
			result.append("--");
		}
		return result.toString();
	}
}

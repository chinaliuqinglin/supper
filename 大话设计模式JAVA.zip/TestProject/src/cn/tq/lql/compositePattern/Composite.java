package cn.tq.lql.compositePattern;

import java.util.ArrayList;
import java.util.List;

public class Composite extends Componet {
	private List<Componet> children=new ArrayList<Componet>();
	
	public Composite(String name) {
		super(name);
	}

	@Override
	public void add(Componet componet) {
		children.add(componet);
	}

	@Override
	public void remove(Componet componet) {
		children.remove(componet);

	}

	@Override
	public void display(int depth) {
		System.out.println(getFormaterByDepth(depth) + name);
		for(Componet componet:children){
			componet.display(depth+1);
		}

	}

}

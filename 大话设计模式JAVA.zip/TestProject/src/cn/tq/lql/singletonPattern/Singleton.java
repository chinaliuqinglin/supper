package cn.tq.lql.singletonPattern;

public class Singleton {
	private static Singleton instance;

	private static Singleton instanceTwo = new Singleton();
	private static Singleton instanceThree = new Singleton();

	private Singleton() {
	}

	static {
		instanceThree = new Singleton();
	}

	public static  Singleton getInstance() {
	
		return instance;
	}

	public static Singleton getInstance2() {
		if (instance == null) {
			synchronized (Singleton.class) {
				if (instance == null) {
					instance = new Singleton();
				}
			}
		}
		return instance;
	}

	public static Singleton getInstanceTwo() {
		return instanceTwo;
	}

	public static Singleton getInstanceThree() {
		return instanceThree;
	}

}

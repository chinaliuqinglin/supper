package cn.tq.lql.facadePattern;

public class SubSystemC {
	public void methodC(){
		System.out.println("methodC");
	}
}

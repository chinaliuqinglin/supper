package cn.tq.lql.facadePattern;

public class SubSystemA {
	public void methodA(){
		System.out.println("methodA");
	}
}

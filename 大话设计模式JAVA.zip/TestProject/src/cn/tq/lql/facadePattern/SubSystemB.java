package cn.tq.lql.facadePattern;

public class SubSystemB {
	
	public void methodB(){
		System.out.println("methodB");
	}
}

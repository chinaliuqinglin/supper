package cn.tq.lql.facadePattern;

public class Facede {
	SubSystemA subSystemA;
	SubSystemB subSystemB;
	SubSystemC subSystemC;

	public Facede() {
		subSystemA = new SubSystemA();
		subSystemB = new SubSystemB();
		subSystemC = new SubSystemC();
	}

	public void methodsA() {
		subSystemA.methodA();
		subSystemB.methodB();
		System.out.println("--------------------");
	}

	public void methodsB() {
		subSystemB.methodB();
		subSystemC.methodC();
		System.out.println("--------------------");
	}

	public void methodsC() {
		subSystemC.methodC();
		subSystemA.methodA();
		System.out.println("--------------------");
	}
}

package cn.tq.lql.mediatorPattern;

public class ConcreateMediator extends Mediator {
	private ConcreateColleagueA colleagueA;
	private ConcreateColleagueB colleagueB;

	public void setConlleagueA(ConcreateColleagueA colleagueA) {
		this.colleagueA = colleagueA;
	}

	public void setConlleagueB(ConcreateColleagueB colleagueB) {
		this.colleagueB = colleagueB;
	}

	@Override
	public void send(String msg, Colleague colleague) {
		if(colleagueA==colleague){
			colleagueB.newNotify(msg);	
		}else{
			colleagueA.newNotify(msg);	
		}

	}

}

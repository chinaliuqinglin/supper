package cn.tq.lql.mediatorPattern;

public abstract class Mediator {
	public abstract void send(String msg,Colleague colleague);

}

package cn.tq.lql.mediatorPattern;

public class ConcreateColleagueB extends Colleague {

	public ConcreateColleagueB(Mediator mediator) {
		super(mediator);
	}

	public void send(String msg) {
		mediator.send(msg, this);
	}

	@Override
	protected void newNotify(String msg) {
		System.out.println("colleagueB get message:" + msg);
	}

}

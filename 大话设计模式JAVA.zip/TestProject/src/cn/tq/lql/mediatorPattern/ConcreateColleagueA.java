package cn.tq.lql.mediatorPattern;

public class ConcreateColleagueA extends Colleague {

	public ConcreateColleagueA(Mediator mediator) {
		super(mediator);
	}
	

	public void send(String msg){
		mediator.send(msg, this);
	}
	

	@Override
	protected void newNotify(String msg) {
		System.out.println("colleagueA get message:"+msg);		
	}

}

package cn.tq.lql.adapterPattern;

public class Target {
	public void request(){
		System.out.println("��ͨ����");
	}
}

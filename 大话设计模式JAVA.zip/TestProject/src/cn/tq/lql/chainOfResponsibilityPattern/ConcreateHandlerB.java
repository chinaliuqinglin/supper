package cn.tq.lql.chainOfResponsibilityPattern;

public class ConcreateHandlerB extends Handler {

	@Override
	public void handleRequest(int request) {
		System.out.println("ConcreateHandlerB ��������");
		System.out.println("handle before request="+request);
		request*=2;
		System.out.println("handle after request="+request);
		if(null!=successor)
			successor.handleRequest(request);
		else
			System.out.println("handle over");
	}

}

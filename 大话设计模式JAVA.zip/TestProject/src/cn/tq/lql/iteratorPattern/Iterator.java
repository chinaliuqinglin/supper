package cn.tq.lql.iteratorPattern;

public abstract class Iterator<E>{
	public abstract E first();
	public abstract E next();
	public abstract E last();
	public abstract boolean isDone();
	public abstract E currentItem();
}

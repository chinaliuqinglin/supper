package cn.tq.lql.iteratorPattern;

public class ConcreateAggregate<E> extends Aggregate<E> {
	private Object[] list;
	private int size;
	private int index;

	public ConcreateAggregate(int size) {
		this.size = size;
		this.index = 0;
		this.list = new Object[size];
	}

	@Override
	public void add(E object) {
		list[index++] = object;
		size++;
	}

	@SuppressWarnings("unchecked")
	@Override
	public E get(int index) {
		return (E)list[index];
	}

	@Override
	public int getSize() {
		return list.length;
	}

	@Override
	public Iterator<E> createIterator() {
		return new ConcreateIterator<E>(this);
	}

}

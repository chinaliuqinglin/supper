package cn.tq.lql.iteratorPattern;

public class ConcreateIterator<E> extends Iterator<E> {
	
	private int current;
	private Aggregate<E> aggregate;

	public ConcreateIterator(ConcreateAggregate<E> aggregate){
		this.aggregate=aggregate;
	}
	
	@Override
	public E first() {
		return (E)aggregate.get(0);
	}

	@Override
	public E next() {
		return (E)aggregate.get(current++);
	}

	@Override
	public E last() {
		return (E)aggregate.get(aggregate.getSize()-1);
	}

	@Override
	public boolean isDone() {
		return current>=aggregate.getSize()?true:false;
	}

	@Override
	public E currentItem() {
		return aggregate.get(current>0?current-1:0);
	}

}

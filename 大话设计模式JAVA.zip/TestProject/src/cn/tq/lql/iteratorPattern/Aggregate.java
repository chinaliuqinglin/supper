package cn.tq.lql.iteratorPattern;

public abstract class Aggregate<E> {
	public abstract void add(E object);

	public abstract E get(int idenx);

	public abstract int getSize();

	public abstract Iterator<E> createIterator();
}

package cn.tq.lql.iteratorPattern;

/**
 * ������ģʽ(iterator pattern): �ṩһ�ַ���˳�����һ���ۺ϶����еĸ���Ԫ��, ���ֲ���¶���ڲ��ı�ʾ
 * 
 * @author loyal
 *
 */
public class MainTest {
	public static void main(String[] args) {
		Aggregate<String> myList = new ConcreateAggregate<String>(5);
		myList.add("1");
		myList.add("2");
		myList.add("3");
		myList.add("4");
		myList.add("5");
		System.out.println("myList size=" + myList.getSize());

		Iterator<String> myIterator = myList.createIterator();

		System.out.println("myIterator fist="+myIterator.first());
		System.out.println("myIterator last="+myIterator.last());
		System.out.println("myIterator current="+myIterator.currentItem());
		while (!myIterator.isDone()) {
			System.out.println(myIterator.next());
		}
		System.out.println("myIterator current="+myIterator.currentItem());

	}
}

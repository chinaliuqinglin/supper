package cn.tq.lql.factoryMethodPattern;

public interface CreateFactory {
	public Product createProduct();
}

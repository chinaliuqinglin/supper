package cn.tq.lql.factoryMethodPattern;

public class RealProductBCreateFactory implements CreateFactory{

	@Override
	public Product createProduct() {
		return new RealProductB();
	}

}

package cn.tq.lql.factoryMethodPattern;

public class RealProductA implements Product{

	@Override
	public void show() {
		System.out.println(RealProductA.class.getName());
	}

}

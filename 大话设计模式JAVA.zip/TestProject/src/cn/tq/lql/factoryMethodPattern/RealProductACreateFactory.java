package cn.tq.lql.factoryMethodPattern;

public class RealProductACreateFactory implements CreateFactory{

	@Override
	public Product createProduct() {
		return new RealProductA();
	}

}

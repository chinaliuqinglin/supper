package cn.tq.lql.factoryMethodPattern;

public interface Product {
	public void show();
}

package cn.tq.lql.factoryMethodPattern;

public class RealProductB implements Product{

	@Override
	public void show() {
		System.out.println(RealProductB.class.getName());
	}

}

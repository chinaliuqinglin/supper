package cn.tq.lql.bio.socket.test;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Set;

public class ServerThread extends Thread {
	Socket socket;
	Set<Socket> list;

	public ServerThread(Socket socket, Set<Socket> list) {
		this.socket = socket;
		this.list = list;
	}

	@Override
	public void run() {
		try {
			while (true) {
				InputStream is = socket.getInputStream();
				if (is.available() == 0) {
					continue;
				}
				byte[] data = new byte[1024];
				while ((is.read(data)) != -1) {
					for (Socket socket : list) {
						if (socket != this.socket) {
							OutputStream os = socket.getOutputStream();
							os.write(data);
							os.flush();
						}
					}
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

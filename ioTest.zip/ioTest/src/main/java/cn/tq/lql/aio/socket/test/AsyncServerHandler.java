package cn.tq.lql.aio.socket.test;

import java.net.InetSocketAddress;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.util.concurrent.CountDownLatch;

public class AsyncServerHandler extends Thread {
	public CountDownLatch latch;
	public AsynchronousServerSocketChannel serverSocketChannel;

	@Override
	public void run() {
		try {
			
			serverSocketChannel = AsynchronousServerSocketChannel.open();
			serverSocketChannel.bind(new InetSocketAddress(8888));
			
			System.out.println("aio socket server start!");
			
			latch = new CountDownLatch(1);
			serverSocketChannel.accept(this,new ServerAcceptHandler());
			latch.await();
			
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}
}

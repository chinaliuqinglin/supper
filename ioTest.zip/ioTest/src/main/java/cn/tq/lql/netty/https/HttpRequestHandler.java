package cn.tq.lql.netty.https;

import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpRequest;

public class HttpRequestHandler {
	public void httpResponse(HttpRequest request,FullHttpResponse httpResponse) {

	}
}

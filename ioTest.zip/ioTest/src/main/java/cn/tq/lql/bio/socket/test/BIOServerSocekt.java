package cn.tq.lql.bio.socket.test;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

public class BIOServerSocekt {

	private static Set<Socket> list = new HashSet<Socket>();

	public static void main(String[] args) {
		ServerSocket server = null;
		try {
			server = new ServerSocket(8888);
			System.out.println("bio socket Server start!");
			while (true) {
				System.out.println("server start accept!");
				Socket socket = server.accept();
				System.out.println("server  accept!");
				list.add(socket);
				socket.getOutputStream().write("welcome join aio chat room,you can start send message".getBytes());
				socket.getOutputStream().flush();
				new ServerThread(socket, list).start();
			}

		} catch (IOException e) {
			e.printStackTrace();
			try {
				server.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}

	}
}

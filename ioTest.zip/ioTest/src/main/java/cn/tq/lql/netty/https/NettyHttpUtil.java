package cn.tq.lql.netty.https;

public class NettyHttpUtil {
	public static HttpRequestHandler ACTION = new ActionHttpRequestHandler();
	public static HttpRequestHandler TEXT = new TextHttpRequestHandler();
	public static HttpRequestHandler STREAM = new StreamHttpRequestHandler();

	public static HttpRequestHandler getHttpRequestTypeByURL(String url) {
		if (null == url || url.equals("")) {
			return ACTION;
		} else {
			String[] urls = url.split("\\.");
			if (urls.length == 1) {
				return ACTION;
			}
			if (urls[1].equals("html") || urls[1].equals("css") || urls[1].equals("js") || urls[1].equals("txt")) {
				return TEXT;
			}
			return STREAM;
		}
	}
}

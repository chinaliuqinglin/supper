package cn.tq.lql.netty.https;

import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpRequest;

public class ActionHttpRequestHandler extends HttpRequestHandler {

	@Override
	public void httpResponse(HttpRequest request, FullHttpResponse httpResponse) {
		String result = null;
		try {
			String[] urls = request.uri().split("/");
			Object obj = NettyBeanUtil.getNettyBeanByName(urls[1]);
			result = obj.getClass().getMethod(urls[2]).invoke(obj).toString();
		} catch (Exception e) {
			e.printStackTrace();
			result = "System Error";
		}
		httpResponse.content().writeBytes(result.toString().getBytes());
		httpResponse.headers().set(HttpHeaderNames.CONTENT_TYPE, "text/html;charset=UTF-8");
		httpResponse.headers().setInt(HttpHeaderNames.CONTENT_LENGTH, httpResponse.content().readableBytes());
	}

}

package cn.tq.lql.netty.https;

import java.util.HashMap;
import java.util.Map;

public class NettyBeanUtil {
	private static Map<String, Object> beans = new HashMap<String, Object>();

	static {
		beans.put("test", new Test());
	}

	public static Object getNettyBeanByName(String name) {
		return beans.get(name);
	}
}

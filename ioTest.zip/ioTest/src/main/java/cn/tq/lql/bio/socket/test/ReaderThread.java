package cn.tq.lql.bio.socket.test;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

public class ReaderThread extends Thread {
	private Socket socket;

	public ReaderThread(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			while (true) {
				InputStream is = socket.getInputStream();
				if(is.available()==0){
					continue;
				}
				byte[] data = new byte[1024];
				int len;
				while((len = is.read(data))!=-1){
					System.out.println("receive msg："+new String(data, 0, len));
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				socket.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
}

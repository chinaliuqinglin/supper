package cn.tq.lql.nio.socket.test;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class NIOServerSocket {
	private static Selector selector;
	private static ServerSocketChannel serverChannel;
	private static Set<SocketChannel> clientsMap = new HashSet<SocketChannel>();

	private static void sendMsg(SocketChannel sc, ByteBuffer buffer) throws Exception {
		for (SocketChannel socketChannel : clientsMap) {
			if (sc != socketChannel) {
				buffer.flip();
				socketChannel.register(selector, SelectionKey.OP_READ);
				socketChannel.write(buffer);
			}
		}
	}

	public static void main(String[] args) {
		try {
			selector = Selector.open();
			serverChannel = ServerSocketChannel.open();
			serverChannel.configureBlocking(false);
			serverChannel.socket().bind(new InetSocketAddress(8888), 1024);
			serverChannel.register(selector, SelectionKey.OP_ACCEPT);

			System.out.println("nio socket server start!");

			while (true) {
				try {
					selector.select(1000);
					Set<SelectionKey> keys = selector.selectedKeys();
					Iterator<SelectionKey> it = keys.iterator();
					SelectionKey key = null;
					while (it.hasNext()) {
						key = it.next();
						it.remove();
						try {
							if (key.isValid()) {
								if (key.isAcceptable()) {
									System.out.println("someone join us");
									ServerSocketChannel ssc = (ServerSocketChannel) key.channel();
									SocketChannel sc = ssc.accept();
									System.out.println(sc.getRemoteAddress());
									sc.configureBlocking(false);
									sc.register(selector, SelectionKey.OP_READ);
									byte[] bytes = "welcome join nio chat room,you can start send message".getBytes();
									ByteBuffer writeBuffer = ByteBuffer.allocate(bytes.length);
									writeBuffer.put(bytes);
									writeBuffer.flip();
									sc.write(writeBuffer);
									clientsMap.add(sc);
								}
								if (key.isReadable()) {
									SocketChannel sc = (SocketChannel) key.channel();
									ByteBuffer buffer = ByteBuffer.allocate(1024);
									int readBytes = sc.read(buffer);
									if (readBytes > 0) {
										sendMsg(sc, buffer);
									} else if (readBytes < 0) {
										key.cancel();
										sc.close();
									}
								}
							}
						} catch (Exception e) {
							if (key != null) {
								key.cancel();
								if (key.channel() != null) {
									key.channel().close();
								}
							}
						}
					}
				} catch (Throwable t) {
					t.printStackTrace();
				}
			}
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
			try {
				selector.close();
			} catch (Exception ee) {
				// TODO 自动生成的 catch 块
				ee.printStackTrace();
			}
		}
	}
}

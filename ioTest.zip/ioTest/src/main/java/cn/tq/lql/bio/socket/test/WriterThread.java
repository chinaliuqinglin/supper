package cn.tq.lql.bio.socket.test;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

public class WriterThread extends Thread {
	private Socket socket;

	public WriterThread(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		Scanner sc = new Scanner(System.in);
		try {
			while (true) {
				System.out.println("say something：");
				if (sc.hasNextLine()) {
					String str = sc.nextLine();
					OutputStream ot=socket.getOutputStream();
					ot.write(str.getBytes());
					ot.flush();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			sc.close();
			try {
				socket.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
}

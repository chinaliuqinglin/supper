package cn.tq.lql.netty.https;

public class Test {
	public String test() {
		return "{test:true}";
	}

}

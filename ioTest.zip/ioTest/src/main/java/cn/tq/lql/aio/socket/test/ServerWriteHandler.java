package cn.tq.lql.aio.socket.test;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;

public class ServerWriteHandler implements CompletionHandler<Integer, ByteBuffer> {
	private AsynchronousSocketChannel currentChannel;

	public ServerWriteHandler(AsynchronousSocketChannel currentChannel) {
		this.currentChannel = currentChannel;
	}

	@Override
	public void completed(Integer result, ByteBuffer buffer) {
		if (buffer.hasRemaining()) {
			currentChannel.write(buffer, buffer, this);  
		}
	}

	@Override
	public void failed(Throwable exc, ByteBuffer attachment) {
		try {
			System.out.println("server write error ,channel close");
			currentChannel.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

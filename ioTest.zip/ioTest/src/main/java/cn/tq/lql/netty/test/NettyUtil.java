package cn.tq.lql.netty.test;

public class NettyUtil {
	public static String ENG_IDE="fuck";
}

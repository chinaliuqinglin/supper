package cn.tq.lql.aio.socket.test;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.CountDownLatch;

public class ClientReadHandler implements CompletionHandler<Integer, ByteBuffer> {
	private AsynchronousSocketChannel clientChannel;
	private CountDownLatch latch;

	public ClientReadHandler(AsynchronousSocketChannel clientChannel, CountDownLatch latch) {
		this.clientChannel = clientChannel;
		this.latch = latch;
	}

	@Override
	public void completed(Integer result, ByteBuffer buffer) {
		try {
			buffer.flip();
			byte[] bytes = new byte[buffer.remaining()];
			buffer.get(bytes);
			String msg = new String(bytes, "UTF-8");
			System.out.println("receive msg:" + msg);
			buffer.clear();
			clientChannel.read(buffer,buffer, new ClientReadHandler(clientChannel, latch));
			System.out.println("say something：");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void failed(Throwable exc, ByteBuffer buffer) {
		exc.printStackTrace();
		System.err.println("client read data error...");
		try {
			clientChannel.close();
			latch.countDown();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

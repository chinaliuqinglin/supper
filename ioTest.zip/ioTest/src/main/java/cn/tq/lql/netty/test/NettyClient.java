package cn.tq.lql.netty.test;

import java.util.Scanner;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;

public class NettyClient {
	public static void main(String[] args) {
		try {
			EventLoopGroup group = new NioEventLoopGroup();

			Bootstrap bootstrap = new Bootstrap();
			bootstrap.group(group).channel(NioSocketChannel.class).handler(new SocketClientInitializer());

			try {
				ChannelFuture future = bootstrap.connect("127.0.0.1", 8888).sync();

				Scanner sc = new Scanner(System.in);
				try {
					while (true) {
						System.out.println("say something：");
						if (sc.hasNextLine()) {
							String msg = sc.nextLine()+NettyUtil.ENG_IDE;
							ByteBuf message = Unpooled.buffer(msg.getBytes().length);
							message.writeBytes(msg.getBytes());
							future.channel().writeAndFlush(message);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					sc.close();
				}

				future.channel().closeFuture().sync();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				group.shutdownGracefully();
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}
}

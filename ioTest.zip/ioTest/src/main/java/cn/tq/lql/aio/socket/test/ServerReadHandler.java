package cn.tq.lql.aio.socket.test;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.Set;

public class ServerReadHandler implements CompletionHandler<Integer, ByteBuffer> {
	private Set<AsynchronousSocketChannel> channels;
	private AsynchronousSocketChannel currentChannel;

	public ServerReadHandler(Set<AsynchronousSocketChannel> channels, AsynchronousSocketChannel currentChannel) {
		this.channels = channels;
		this.currentChannel = currentChannel;
	}

	@Override
	public void completed(Integer result, ByteBuffer buffer) {
		try {
			if (result > 0) {
				buffer.flip();
				byte[] bytes = new byte[buffer.remaining()];
				buffer.get(bytes);
				for (AsynchronousSocketChannel currentChannel : channels) {
					if (this.currentChannel != currentChannel) {
						ByteBuffer writeBuffer = ByteBuffer.allocate(1024);
						writeBuffer.put(bytes);
						writeBuffer.flip();
						currentChannel.write(writeBuffer, writeBuffer, new ServerWriteHandler(currentChannel));
					}
				}

				ByteBuffer newBuffer = ByteBuffer.allocate(1024);
				currentChannel.read(newBuffer, newBuffer, this);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void failed(Throwable exc, ByteBuffer buffer) {
		System.out.println("server read data error...");
		exc.printStackTrace();
		try {
			this.currentChannel.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

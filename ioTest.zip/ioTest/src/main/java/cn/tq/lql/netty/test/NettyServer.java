package cn.tq.lql.netty.test;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;

public class NettyServer {

	public static void main(String[] args) {
		EventLoopGroup boosGroup=new NioEventLoopGroup();
		EventLoopGroup workerGroup=new NioEventLoopGroup();
		
		try{
			ServerBootstrap bootStrap=new ServerBootstrap();
			bootStrap.group(boosGroup,workerGroup).channel(NioServerSocketChannel.class)
			.handler(new LoggingHandler(LogLevel.ERROR))
			.childHandler(new SocketServerInitializer())
            .option(ChannelOption.SO_BACKLOG, 128) //设置TCP缓冲区  
            .option(ChannelOption.SO_SNDBUF, 32 * 1024) //设置发送数据缓冲大小  
            .option(ChannelOption.SO_RCVBUF, 32 * 1024) //设置接受数据缓冲大小  
            .childOption(ChannelOption.SO_KEEPALIVE, true); //保持连接  
    ChannelFuture future = bootStrap.bind(8888).sync();  
    System.out.println("netty socket Server start!");
    future.channel().closeFuture().sync();  
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}

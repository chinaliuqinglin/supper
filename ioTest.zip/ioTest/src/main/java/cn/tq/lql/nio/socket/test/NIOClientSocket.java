package cn.tq.lql.nio.socket.test;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class NIOClientSocket {
	private static Selector selector;
	private static SocketChannel socketChannel;

	public static void main(String[] args) {
		try {
			selector = Selector.open();
			socketChannel = SocketChannel.open();
			socketChannel.configureBlocking(false);
			socketChannel.connect(new InetSocketAddress("127.0.0.1", 8888));
			socketChannel.register(selector, SelectionKey.OP_CONNECT);
			new WriterThread(selector, socketChannel).start();
			while (true) {
				try {
					selector.select(1000);
					Set<SelectionKey> keys = selector.selectedKeys();
					Iterator<SelectionKey> it = keys.iterator();
					SelectionKey key = null;
					while (it.hasNext()) {
						key = it.next();
						it.remove();
						if (key.isValid()) {
							SocketChannel sc = (SocketChannel) key.channel();
							if (key.isConnectable()) {
								if (!sc.finishConnect())
									System.exit(1);
								if (!key.isReadable()) {
									socketChannel.register(selector, SelectionKey.OP_READ);
								}
							}
							ByteBuffer buffer = ByteBuffer.allocate(1024);
							int readBytes = sc.read(buffer);
							if (readBytes > 0) {
								buffer.flip();
								byte[] bytes = new byte[buffer.remaining()];
								buffer.get(bytes);
								String result = new String(bytes, "UTF-8");
								System.out.println("receive msg：" + result);
							} else if (readBytes < 0) {
								key.cancel();
								sc.close();
							}
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.exit(1);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				selector.close();
			} catch (IOException e1) {
				// TODO 自动生成的 catch 块
				e1.printStackTrace();
			}
			System.exit(1);
		}
	}
}

package cn.tq.lql.nio.socket.test;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class WriterThread extends Thread {
	private  Selector selector;
	private  SocketChannel socketChannel;

	public WriterThread(Selector selector,SocketChannel socketChannel) {
		this.selector=selector;
		this.socketChannel = socketChannel;
	}

	@Override
	public void run() {
		Scanner sc = new Scanner(System.in);
		try {
			while (true) {
				System.out.println("say something：");
				if (sc.hasNextLine()) {
					String msg = sc.nextLine();
			        byte[] bytes = msg.getBytes();  
			        ByteBuffer writeBuffer = ByteBuffer.allocate(bytes.length);  
			        writeBuffer.put(bytes);  
			        writeBuffer.flip();  
			        socketChannel.write(writeBuffer);  
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			sc.close();
			try {
				socketChannel.close();
				selector.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
}

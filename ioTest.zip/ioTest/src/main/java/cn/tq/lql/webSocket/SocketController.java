package cn.tq.lql.webSocket;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/websocket/{userName}")
public class SocketController {
	private static Map<String, Session> sessions = new HashMap<String, Session>();

	public void sendMessage(String message) throws IOException {
		System.out.println(sessions.size() + " user receive msg");
		for (Map.Entry<String, Session> entry : sessions.entrySet()) {
			entry.getValue().getBasicRemote().sendText(message);
		}
	}
	
	@OnOpen
	public void onOpen(@PathParam("userName") String userName, Session session) throws IOException {
		System.out.println(userName + " open");
		sessions.put(userName, session);
		sendMessage(userName + " join this room!");
	}

	@OnClose
	public void onClose(@PathParam("userName") String userName, Session session) throws IOException {
		System.out.println(userName + " close");
		sessions.remove(userName);
		sendMessage(userName + " quit this room!");
	}

	@OnMessage
	public void onMessage(@PathParam("userName") String userName, String message) throws IOException {
		System.out.println(message);
		sendMessage(userName + " say：" + message);
	}

	@OnError
	public void onError(@PathParam("userName") String userName, Session session, Throwable error) throws IOException {
		sendMessage("用户" + userName + "发生错误：/n" + error.getMessage());
	}
}

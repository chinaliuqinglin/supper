package cn.tq.lql.netty.test;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;

public class SocketServerHandler extends SimpleChannelInboundHandler<String>  {
	public static ChannelGroup channels = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception {  
        Channel clientChannel = ctx.channel();
        clientChannel.writeAndFlush("welcome join netty chat room,you can start send message"+NettyUtil.ENG_IDE);
        channels.add(clientChannel);
    }

    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {  
        channels.remove(ctx.channel());
    }
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, String msg) throws Exception {
    	System.out.println(msg);
        Channel incoming = ctx.channel();
        for (Channel channel : channels) {
            if (channel != incoming){
                channel.writeAndFlush(msg + NettyUtil.ENG_IDE);
            } 
        }
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception { 
    	
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception { 
    }
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        channels.remove(ctx.channel());
        cause.printStackTrace();
        ctx.close();
    }
}

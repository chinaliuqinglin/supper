package cn.tq.lql.netty.https;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpRequest;

public class TextHttpRequestHandler extends HttpRequestHandler {

	@Override
	public void httpResponse(HttpRequest request, FullHttpResponse httpResponse) {
		String result = null;
		try {
			BufferedReader br = new BufferedReader(
					new FileReader("D:/haManSpace/syncodespace/onesys/webroot/" + request.uri()));
			StringBuilder builder = new StringBuilder();
			String s = null;
			while ((s = br.readLine()) != null) {
				builder.append(System.lineSeparator() + s);
			}
			br.close();
			result = builder.toString();
		} catch (IOException e) {
			e.printStackTrace();
			result = "System Error";
		}
		httpResponse.content().writeBytes(result.toString().getBytes());
		httpResponse.headers().set(HttpHeaderNames.CONTENT_TYPE, "text/html;charset=UTF-8");
		httpResponse.headers().setInt(HttpHeaderNames.CONTENT_LENGTH, httpResponse.content().readableBytes());
	}

}

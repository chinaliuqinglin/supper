package cn.tq.lql.netty.test;

import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.DelimiterBasedFrameDecoder;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;

public class SocketServerInitializer extends ChannelInitializer<SocketChannel> {

	@Override
	protected void initChannel(SocketChannel ch) throws Exception {
		System.out.println("someone join ");
		// TODO 自动生成的方法存根
		ch.pipeline().addLast(new DelimiterBasedFrameDecoder(2048, Unpooled.copiedBuffer(NettyUtil.ENG_IDE.getBytes())));
		ch.pipeline().addLast(new StringDecoder());
		ch.pipeline().addLast(new StringEncoder());
		ch.pipeline().addLast(new SocketServerHandler());
	}

}

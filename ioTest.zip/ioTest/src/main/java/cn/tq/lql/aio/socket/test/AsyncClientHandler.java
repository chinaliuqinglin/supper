package cn.tq.lql.aio.socket.test;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.CountDownLatch;

public class AsyncClientHandler extends Thread implements CompletionHandler<Void, AsyncClientHandler> {
	private CountDownLatch latch;
	private AsynchronousSocketChannel clientChannel;

	@Override
	public void run() {
		try {
			latch = new CountDownLatch(1);
			clientChannel = AsynchronousSocketChannel.open();
			clientChannel.connect(new InetSocketAddress("127.0.0.1", 8888), this, this);
			ByteBuffer buffer=ByteBuffer.allocate(1024);
			clientChannel.read(buffer,buffer, new ClientReadHandler(clientChannel, latch));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void completed(Void result, AsyncClientHandler clientHandler) {
		
	}

	@Override
	public void failed(Throwable exc, AsyncClientHandler clientHandler) {
        try {  
        	exc.printStackTrace();  
            clientChannel.close();  
            latch.countDown();  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
	}

	public void sendMsg(String msg) {
		byte[] data = msg.getBytes();
		ByteBuffer writeBuffer = ByteBuffer.allocate(data.length);
		writeBuffer.put(data);
		writeBuffer.flip();
		clientChannel.write(writeBuffer, writeBuffer, new ClientWriteHandler(clientChannel, latch));
	}

}

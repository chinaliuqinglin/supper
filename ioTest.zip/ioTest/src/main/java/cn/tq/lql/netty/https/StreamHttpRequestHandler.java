package cn.tq.lql.netty.https;

import java.io.FileInputStream;
import java.io.InputStream;

import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpRequest;

public class StreamHttpRequestHandler extends HttpRequestHandler {

	@Override
	public void httpResponse(HttpRequest request, FullHttpResponse httpResponse) {
		String[] urls = request.uri().split("\\.");
		try {
			InputStream is = new FileInputStream("D:/haManSpace/syncodespace/onesys/webroot/" + request.uri());
			byte[] b = new byte[1024];
			while (is.read(b) != -1) {
				httpResponse.content().writeBytes(b);
			}
			is.close();
			httpResponse.headers().set(HttpHeaderNames.CONTENT_TYPE, "image/" + urls[urls.length - 1]);
		} catch (Exception e) {
			e.printStackTrace();
			httpResponse.content().writeBytes("System Error".toString().getBytes());
			httpResponse.headers().set(HttpHeaderNames.CONTENT_TYPE, "text/html;charset=UTF-8");
		}
		httpResponse.headers().setInt(HttpHeaderNames.CONTENT_LENGTH, httpResponse.content().readableBytes());

	}

}

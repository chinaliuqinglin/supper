package cn.tq.lql.aio.socket.test;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.HashSet;
import java.util.Set;

public class ServerAcceptHandler implements CompletionHandler<AsynchronousSocketChannel, AsyncServerHandler> {
	private Set<AsynchronousSocketChannel> channels=new HashSet<AsynchronousSocketChannel>();
	@Override
	public void completed(AsynchronousSocketChannel channel, AsyncServerHandler serverHandler) {
		serverHandler.serverSocketChannel.accept(serverHandler, this);
		channels.add(channel);
		
		byte[] writeBytes = "welcome join nio chat room,you can start send message".getBytes();
		ByteBuffer writeBuffer = ByteBuffer.allocate(1024);
		writeBuffer.put(writeBytes);
		writeBuffer.flip();
		channel.write(writeBuffer);
		
		ByteBuffer readBuffer = ByteBuffer.allocate(1024);
		channel.read(readBuffer, readBuffer, new ServerReadHandler(channels,channel));
	}

	@Override
	public void failed(Throwable exc, AsyncServerHandler serverHandler) {
		exc.printStackTrace();
		serverHandler.latch.countDown();
	}
}

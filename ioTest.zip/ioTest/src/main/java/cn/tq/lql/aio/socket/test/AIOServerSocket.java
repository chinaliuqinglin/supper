package cn.tq.lql.aio.socket.test;

public class AIOServerSocket {
	public static void main(String[] args) {
		new AsyncServerHandler().start();
	}
}




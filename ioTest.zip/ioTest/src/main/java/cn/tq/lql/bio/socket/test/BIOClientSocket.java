package cn.tq.lql.bio.socket.test;

import java.io.IOException;
import java.net.Socket;

public class BIOClientSocket {

	public static void main(String[] args) {
		Socket socket = null;
		try {

			socket = new Socket("127.0.0.1", 8888);
			new WriterThread(socket).start();
			new ReaderThread(socket).start();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				socket.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
}

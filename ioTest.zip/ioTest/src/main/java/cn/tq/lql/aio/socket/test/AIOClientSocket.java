package cn.tq.lql.aio.socket.test;

import java.util.Scanner;

public class AIOClientSocket {
	private static AsyncClientHandler clientHandle;

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		try {

			clientHandle = new AsyncClientHandler();
			clientHandle.start();

			System.out.println("say something：");
			while (scanner.hasNextLine()) {
				clientHandle.sendMsg(scanner.nextLine());
				System.out.println("say something：");
			}
		} catch (Exception e) {
			e.printStackTrace();
			scanner.close();
		}
	}
}

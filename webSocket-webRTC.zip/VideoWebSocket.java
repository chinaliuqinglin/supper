package com.zhizheng.socket;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/websocket/{roomId}")
public class VideoWebSocket {
	private static Map<String, CopyOnWriteArraySet<VideoWebSocket>> rooms = new HashMap<String, CopyOnWriteArraySet<VideoWebSocket>>();
	private String roomId;
	private Session session;

	public VideoWebSocket() {
	}

	@OnOpen
	public void onOpen(Session session, @PathParam(value = "roomId") String roomId) {
		this.session = session;
		CopyOnWriteArraySet<VideoWebSocket> webSocketSet = rooms.get(roomId);
		if (null == webSocketSet)
			webSocketSet = new CopyOnWriteArraySet<VideoWebSocket>();
		webSocketSet.add(this);
		rooms.put(roomId, webSocketSet);
	}

	@OnClose
	public void onClose(@PathParam(value = "roomId") String roomId) {
		CopyOnWriteArraySet<VideoWebSocket> webSocketSet = rooms.get(roomId);
		if (null == webSocketSet)
			return;
		webSocketSet.remove(this); // 从set中删除
	}

	@OnMessage
	public void onMessage(String message, Session session, @PathParam(value = "roomId") String roomId) {
		CopyOnWriteArraySet<VideoWebSocket> webSocketSet = rooms.get(roomId);
		if (null == webSocketSet)
			return;
		for (VideoWebSocket item : webSocketSet) {
			try {
				if (item != this)
					item.sendMessage(message);
			} catch (IOException e) {
				e.printStackTrace();
				continue;
			}
		}
	}

	@OnError
	public void onError(Session session, Throwable error) {
		error.printStackTrace();
	}

	public void sendMessage(String message) throws IOException {
		System.out.println(message);
		this.session.getBasicRemote().sendText(message);
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

}

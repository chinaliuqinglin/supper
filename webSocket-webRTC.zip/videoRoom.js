var websocket = null;  
    if ('WebSocket' in window) {  
        websocket = new WebSocket("wss://www.gnnzfw.com/websocket/"+roomId);  
    } else {  
        alert('当前浏览器 Not support websocket')  
    }  
 
    websocket.onerror = function () {  
    };  
  
    websocket.onopen = function () {  
    }  
    
       var iceServer = {  
           "iceServers" : [ {  
               "url" : "stun:stun.l.google.com:19302"  
           }, {  
               "url" : "turn:numb.viagenie.ca",  
               "username" : "webrtc@live.com",  
               "credential" : "muazkh"  
           } ]  
       };  
     
    
    var pc = new webkitRTCPeerConnection(iceServer);  
  
    pc.onicecandidate = function(event) {
        if (event.candidate !== null) {  
            websocket.send(JSON.stringify({  
                "event" : "candidate",  
                "data" : {  
                    "candidate" : event.candidate  
                }  
            }));  
        }  
    };  
      
    websocket.onmessage = function (event) {  
        if(event.data=="newUser") {  
        	pc.createOffer(sendOfferFn, function(error) {  
                console.log('Failure callback: ' + error);  
            });
        } else {  
        	var json = JSON.parse(event.data); 
        	console.log(json.event);
            if (json.event === "candidate") {  
                pc.addIceCandidate(new RTCIceCandidate(json.data.candidate));  
            } else {  
                pc.setRemoteDescription(new RTCSessionDescription(json.data.sdp));  
                if (json.event === "offer") {  
                    pc.createAnswer(sendAnswerFn, function(error) {  
                        console.log('Failure callback: ' + error);  
                    });  
                }  
            }  
        }  
    }  
  
    pc.onaddstream = function(event) { 
    	$("#video").append($("#video .local:first").prop("outerHTML"));
    	$("#video .local:last").attr("src",URL.createObjectURL(event.stream));
    };  
  
    var sendOfferFn = function(desc) {  
        pc.setLocalDescription(desc);  
        websocket.send(JSON.stringify({  
            "event" : "offer",  
            "data" : {  
                "sdp" : desc  
            }  
        }));  
    }, sendAnswerFn = function(desc) {  
        pc.setLocalDescription(desc);  
        websocket.send(JSON.stringify({  
            "event" : "answer",  
            "data" : {  
                "sdp" : desc  
            }  
        }));  
    };  
  
    navigator.webkitGetUserMedia({  
        "audio" : true,  
        "video" : true  
    },  
    function(stream) {  
        $(".local:first").attr("src",URL.createObjectURL(stream));  
        pc.addStream(stream);  
        websocket.send("newUser");  
    }, function(error) {  
        console.log('getUserMedia error: ' + error);  
    });  

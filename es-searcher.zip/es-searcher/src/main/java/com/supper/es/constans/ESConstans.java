package com.supper.es.constans;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

@SuppressWarnings("resource")
public class ESConstans {
	public static final String HTTP = "http";
	public static final String FALSE = "false";

	public static final String ID = "id";

	public static final String PUT = "put";
	public static final String GET = "get";
	public static final String HEAD = "head";
	public static final String DELETE = "delete";

	public static final String FS = "/";

	public static final String SOURCE = "_source";
	public static final String CREATE = "_create";
	public static final String SEARCH = "_search";

	public static final String FROM = "from";
	public static final String SIZE = "size";
	public static final String SORT = "sort";

	public static final String UTF_8 = "UTF-8";

	public static final String Q = "q";
	public static final String COLON = ":";
	public static final String AND = "&";
	public static final String QUES = "?";
	public static final String EQ = "=";

	public static String SETTING = null;

	static {
		try {
			File path = new File("");
			File file = new File(path.getAbsolutePath() + "/src/main/resources/settings.json");
			String s = "";
			InputStreamReader in = new InputStreamReader(new FileInputStream(file), "UTF-8");
			BufferedReader br = new BufferedReader(in);
			StringBuffer content = new StringBuffer();
			while ((s = br.readLine()) != null) {
				content = content.append(s);
			}
			SETTING = content.toString();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

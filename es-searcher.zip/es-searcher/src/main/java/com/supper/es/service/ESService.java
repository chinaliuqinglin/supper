package com.supper.es.service;

import java.util.Map.Entry;

import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.supper.es.common.CommonUtil;
import com.supper.es.constans.ESConstans;
import com.supper.es.model.ESModel;
import com.supper.es.model.vo.ESModelVo;

@Service
public class ESService {
	@Autowired
	private RestClient client;

	public String getUrlByModel(ESModel model) {
		if (null == model)
			return null;
		String res = model.getIndex() + ESConstans.FS + model.getType();
		if (CommonUtil.validate(model.getId())) {
			res += ESConstans.FS + model.getId();
		}
		return res;
	}

	public String validateUrl(String url) {
		if (!CommonUtil.validate(url)) {
			return ESConstans.FALSE;
		}
		if (!url.substring(0, 1).equals(ESConstans.FS)) {
			url = ESConstans.FS + url;
		}
		return url;
	}

	public String doRequest(String method, String interfaceUrl) {
		try {
			if (!CommonUtil.validate(method) || !CommonUtil.validate(interfaceUrl)) {
				return ESConstans.FALSE;
			}

			Request request = new Request(method, validateUrl(interfaceUrl));
			Response response = client.performRequest(request);
			return EntityUtils.toString(response.getEntity());
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
	}

	public String doRequest(String method, String interfaceUrl, JSONObject param) {
		try {
			if (!CommonUtil.validate(method) || !CommonUtil.validate(interfaceUrl)) {
				return ESConstans.FALSE;
			}

			Request request = new Request(method, validateUrl(interfaceUrl));
			request.setEntity(new NStringEntity(param.toString(), ESConstans.UTF_8));
			Response response = client.performRequest(request);
			return EntityUtils.toString(response.getEntity());
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
	}

	public String addIndex(String indexName) {
		if (!CommonUtil.validate(indexName)) {
			return ESConstans.FALSE;
		}
		try {
			Request request = new Request(ESConstans.PUT, ESConstans.FS + indexName);
			if (CommonUtil.validate(ESConstans.SETTING)) {
				request.setEntity(new NStringEntity(ESConstans.SETTING, ESConstans.UTF_8));
			}
			Response response = client.performRequest(request);
			return EntityUtils.toString(response.getEntity());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ESConstans.FALSE;
	}

	public String deleteIndex(String indexName) {
		if (!CommonUtil.validate(indexName)) {
			return ESConstans.FALSE;
		}
		return doRequest(ESConstans.DELETE, indexName);
	}

	public String addData(ESModel model) {
		if (null == model || !CommonUtil.validate(model.getIndex()) || !CommonUtil.validate(model.getType())
				|| !CommonUtil.validate(model.getId()) || null == model.getObject() || model.getObject().size() == 0) {
			return ESConstans.FALSE;
		}
		return doRequest(ESConstans.PUT, getUrlByModel(model) + ESConstans.FS + ESConstans.CREATE, model.getObject());
	}

	public String deleteData(ESModel model) {
		if (null == model || !CommonUtil.validate(model.getIndex()) || !CommonUtil.validate(model.getType())
				|| !CommonUtil.validate(model.getId())) {
			return ESConstans.FALSE;
		}
		return doRequest(ESConstans.DELETE, getUrlByModel(model));
	}

	public String getData(ESModelVo modelVo) {
		if (null == modelVo || !CommonUtil.validate(modelVo.getIndex()) || !CommonUtil.validate(modelVo.getType())
				|| !CommonUtil.validate(modelVo.getId())) {
			return ESConstans.FALSE;
		}

		String url = getUrlByModel(modelVo);
		if (CommonUtil.validate(modelVo.getSource())) {
			url += ESConstans.FS + modelVo.getSource();
		}
		return doRequest(ESConstans.GET, url);
	}

	public String findData(ESModelVo modelVo) {
		if (null == modelVo || !CommonUtil.validate(modelVo.getIndex()) || !CommonUtil.validate(modelVo.getType())) {
			return ESConstans.FALSE;
		}

		String url = getUrlByModel(modelVo);
		StringBuffer sb = new StringBuffer();
		boolean flag = true;
		if (modelVo.getFrom() == null && modelVo.getSize() == null) {
			flag = false;
			if (modelVo.getPage() != null && modelVo.getRows() != null) {
				flag = true;
				modelVo.setFrom((modelVo.getPage() - 1) * modelVo.getRows());
				modelVo.setSize(modelVo.getRows());
			}
		}

		if (flag) {
			sb.append(ESConstans.QUES).append(ESConstans.FROM).append(ESConstans.EQ).append(modelVo.getFrom()).append(ESConstans.AND)
					.append(ESConstans.SIZE).append(ESConstans.EQ).append(modelVo.getSize());
		}

		if (null != modelVo.getObject() && modelVo.getObject().size() != 0) {
			Integer osize = modelVo.getObject().size();
			if (flag) {
				sb.append(ESConstans.AND);
			} else {
				sb.append(ESConstans.QUES);
			}
			sb.append(ESConstans.Q).append(ESConstans.EQ);
			Integer index = 1;
			for (Entry<String, Object> obj : modelVo.getObject().entrySet()) {
				sb.append(obj.getKey());
				sb.append(ESConstans.COLON);
				sb.append(obj.getValue());
				if (index != osize) {
					++index;
					sb.append(modelVo.getSymbol());
				}
			}

			flag = true;
		}

		if (CommonUtil.validate(modelVo.getSort()) && CommonUtil.validate(modelVo.getSidx())) {
			if (flag) {
				sb.append(ESConstans.AND);
			} else {
				sb.append(ESConstans.QUES);
			}
			sb.append(ESConstans.SORT).append(ESConstans.EQ).append(modelVo.getSidx()).append(ESConstans.COLON)
					.append(modelVo.getSort());
		}
		if (sb.length() > 0) {
			url += ESConstans.FS + ESConstans.SEARCH + sb.toString();
		}
		return doRequest(ESConstans.GET, url);
	}

}

package com.supper.es.model;

import com.alibaba.fastjson.JSONObject;

public class ESModel {
	private String id;
	private String index;
	private String type="_doc";
	private JSONObject object;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public JSONObject getObject() {
		return object;
	}

	public void setObject(JSONObject object) {
		this.object = object;
	}

}

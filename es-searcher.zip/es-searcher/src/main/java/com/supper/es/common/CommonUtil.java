package com.supper.es.common;

public class CommonUtil {
	public static boolean validate(String string) {
		return string != null && !"".equals(string.trim());
	}
}

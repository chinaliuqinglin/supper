package com.supper.es.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.supper.es.model.ESModel;
import com.supper.es.model.vo.ESModelVo;
import com.supper.es.service.ESService;

@Controller
@RequestMapping("/es")
public class ESController {
	@Autowired
	private ESService esService;

	@RequestMapping(value = "/test")
	@ResponseBody
	public void test() {
		System.out.println(esService.deleteIndex("test"));
		System.out.println(esService.addIndex("test"));
		ESModel model = new ESModel();
		model.setId("1");
		model.setIndex("test");
		JSONObject obj = new JSONObject();
		obj.put("title", "事件标题1");
		obj.put("content", "事件内容1");
		model.setObject(obj);
		System.out.println(esService.addData(model));

		model.setId("2");
		obj.put("title", "事件标题2");
		obj.put("content", "事件内容2");
		System.out.println(esService.addData(model));

		ESModelVo modelVo = new ESModelVo();
		modelVo.setId("1");
		modelVo.setIndex("test");
		System.out.println(esService.getData(modelVo));

		modelVo.setId("2");
		System.out.println(esService.getData(modelVo));

		model.setId("3");
		obj.put("title", "事件标题3");
		obj.put("content", "事件内容3");
		System.out.println(esService.addData(model));

		model.setId("4");
		obj.put("title", "事件标题4");
		obj.put("content", "事件内容4");
		System.out.println(esService.addData(model));

		modelVo.setIndex("test");
		System.out.println(esService.findData(modelVo));

		modelVo.setId(null);

		modelVo.setPage(1);
		modelVo.setRows(1);
		System.out.println(esService.findData(modelVo));

		modelVo.setPage(1);
		modelVo.setRows(2);
		System.out.println(esService.findData(modelVo));

		modelVo.setSidx("id");
		System.out.println(esService.findData(modelVo));

		modelVo.setSort("asc");
		System.out.println(esService.findData(modelVo));

	}

	@RequestMapping(value = "/addIndex")
	@ResponseBody
	public String addIndex(String indexName) {
		return esService.addIndex(indexName);
	}

	@RequestMapping(value = "/deleteIndex")
	@ResponseBody
	public String deleteIndex(String indexName) {
		return esService.deleteIndex(indexName);
	}

	@RequestMapping(value = "/addData")
	@ResponseBody
	public String addData(ESModel model) {
		return esService.addData(model);
	}

	@RequestMapping(value = "/deleteData")
	@ResponseBody
	public String deleteData(ESModel model) {
		return esService.deleteData(model);
	}

	@RequestMapping(value = "/findData")
	@ResponseBody
	public String findData(ESModelVo modelVo) {
		return esService.findData(modelVo);
	}

}
